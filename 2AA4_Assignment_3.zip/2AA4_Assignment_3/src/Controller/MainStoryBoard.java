package Controller;//

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Model.AI;
import Model.Board;
import Model.Move;
import Model.Player;
import Resources.Constants;
import View.GameBoardView;
import View.SideBoardView;

public class MainStoryBoard implements ActionListener {
	private Board gameModel; // Gameboard data and rules (MODEL)
	private JFrame mainView; // Main story board GUI (VIEW)
	private GameBoardView gameView; // View of the game board (VIEW)
	private SideBoardView sideView; // View of the side board (VIEW)
	private JLabel infoLabel; // Information label
	private boolean aiPlaying;

	/**
	 * The main story board constructor will create a new gameboard (new game),
	 * create the GUI, and start the game.
	 */
	public MainStoryBoard() {
		Random rand = new Random(); // Randomozer
		gameModel = new Board(); // Creating new board
		gameModel.setCurrPlayer(rand.nextInt(2));
		gameModel.setCurrPhase(Constants.PLACE);
		aiPlaying = false;
		this.createGUI(); // Create the Graphical User Interface
	}

	/**
	 * This method creates the menu for the new game, load game, save game, exit and AI options. 
	 */
	private void createMenu() {
		JMenuBar menuBar = new JMenuBar();
		menuBar.setOpaque(true);

		JMenu menu;
		JMenuItem menuItem;
		menu = new JMenu("File");
		// Add new game
		menuItem = new JMenuItem("New game", KeyEvent.VK_N);
		menuItem.addActionListener(this);
		menu.add(menuItem);
		// Load game
		menuItem = new JMenuItem("Load game", KeyEvent.VK_L);
		menuItem.addActionListener(this);
		menu.add(menuItem);
		// Save game
		menuItem = new JMenuItem("Save game", KeyEvent.VK_S);
		menuItem.addActionListener(this);
		menu.add(menuItem);
		// Exit game
		menuItem = new JMenuItem("Exit", KeyEvent.VK_X);
		menuItem.addActionListener(this);
		menu.add(menuItem);
		// Finish File menu
		menuBar.add(menu);
		// Create options menu
		menu = new JMenu("Options");
		// Play with AI
		menuItem = new JMenuItem("Play with computer", KeyEvent.VK_C);
		menuItem.addActionListener(this);
		menu.add(menuItem);
		// Two players
		menuItem = new JMenuItem("2 Player", KeyEvent.VK_P);
		menuItem.addActionListener(this);
		menu.add(menuItem);

		menuBar.add(menu);
		this.mainView.setJMenuBar(menuBar);
	}

	/**
	 * This method create the Graphical user interface, connects the main frame,
	 * gameboard and side panel together.
	 */
	private void createGUI() {

		this.mainView = new JFrame("Six Men's Morris || Group 19 || The Code Speaks for Itself"); // Set
																									// the
																									// title
		this.mainView.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Biolerplate
																		// JFrame
																		// code
		this.gameView = new GameBoardView(gameModel); // Create the main game
														// view
		this.sideView = new SideBoardView(gameModel);
		this.mainView.setPreferredSize(new Dimension(gameView.getWidth() + 200, gameView.getHeight() + 50));

		// Creating the information panel
		JPanel infoPanel = new JPanel();
		infoPanel.setBackground(Color.white);
		infoPanel.setSize(new Dimension(400, 100));
		// GridBagConstraints c = new GridBagConstraints();

		infoLabel = new JLabel("<html><b><font size=4>Select a colour</font></b><br></html>", JLabel.LEFT);
		infoPanel.add(infoLabel);

		createMenu();
		// Add all the components
		this.mainView.getContentPane().setBackground(new Color(243, 243, 243));
		this.mainView.getContentPane().add(infoPanel, BorderLayout.SOUTH);
		this.mainView.getContentPane().add(gameView, BorderLayout.CENTER);
		this.mainView.getContentPane().add(sideView, BorderLayout.LINE_END);
		this.mainView.pack();
		this.mainView.setVisible(true);
		this.mainView.setLocationRelativeTo(null); // Center of the screen
		this.mainView.setResizable(false);
	}

	/**
	 * The saveGame() method reads from the file "data/gamedata.txt" and saves
	 * the gamemodel.toString() into the file.
	 * 
	 * @throws FileNotFoundException
	 */
	private void saveGame(String filename) throws FileNotFoundException {
		/*
		 * line 1: game state line 2: player 1 data line 3: player 2 data line
		 * 4: current player line 5: current phase (Place, move, mill)
		 */
		PrintWriter out = new PrintWriter(filename); // Create the gamedata file
		out.print(gameModel); // Save the game data to the file
		out.close(); // Close the file
	}

	/**
	 * Default save game with no filename specified
	 * 
	 * @throws FileNotFoundException
	 */
	private void saveGame() throws FileNotFoundException {
		saveGame("gamedata.txt");
	}

	/**
	 * Default load game with no file name specified
	 * 
	 * @throws FileNotFoundException
	 */
	private void loadGame() throws FileNotFoundException {
		loadGame("gamedata.txt");
	}

	/**
	 * The loadGame() method searches for the "data/gamedata.txt" file and
	 * parses the file. After loadGame() parses the file, the method creates a
	 * Board model from the data and sets the gameBoard to the new board.
	 * 
	 * @throws FileNotFoundException
	 */
	private void loadGame(String filename) throws FileNotFoundException {
		// Get content from file
		String content = new Scanner(new File(filename)).useDelimiter("\\Z").next();
		// Split content by the number of lines.
		String[] lines = content.split("\n");
		// Create a gamestate array.
		String[] gameState = lines[0].split(",");
		// Load the array into the model
		gameModel.loadGameData(gameState);
		// Parse and create player 1
		String[] player1 = lines[1].split(",");
		gameModel.setPlayer1(new Player(player1[0], player1[1], player1[2], player1[3]));
		// Parse and create player 2
		String[] player2 = lines[2].split(",");
		gameModel.setPlayer2(new Player(player2[0], player2[1], player2[2], player2[3]));
		// Parse and set the current player
		gameModel.setCurrPlayer(Integer.parseInt(lines[3]));
		// Parse and set the current phase
		gameModel.setCurrPhase(Integer.parseInt(lines[4]));
		// Refresh the program
		refresh();
	}

	/**
	 * This method refreshes the Graphical User Interfaces.
	 */
	private void refresh() {
		gameView.setBoard(gameModel); // Set the new board
		sideView.setBoard(gameModel); // Set the new board
		gameView.repaint(); // Reresh
		sideView.repaint();
	}

	/**
	 * This method creates the infinite while loop and connects the view to the
	 * controller.
	 */
	public void playGame() {
		int currDestination = Constants.EMPTY;
		boolean once = true;
		AI ai = new AI(gameModel.getPlayer1());

		while (true) {
			Move move; // Initiate a move
			if (gameModel.GAMEOVER) {
				// if its gameover, notify the user
				if (gameModel.getWinner().getColor() == Constants.BLUE) {
					infoLabel.setText("<html><b><font size=3>BLUE WINS!</font></b><br></html>");
				} else {
					infoLabel.setText("<html><b><font size=3>RED WINS!</font></b><br></html>");
				}
			} else if (this.gameModel.getCurrPhase() == Constants.PLACE) {
				if (aiPlaying && gameModel.getCurrPlayer() == ai.getPlayer()) {
					gameModel.applyMove(ai.nextBestPlaceMove(gameModel)); // Apply
					refresh();
					gameView.resetDestination();
				} else if (sideView.getCurrentColor() != Constants.EMPTY
						&& gameView.getDestination() != Constants.EMPTY) {
					// This is a valid move
					move = new Move(sideView.getCurrentColor(), gameView.getDestination()); // Create
					gameModel.applyMove(move); // Apply move
					refresh(); // Refresh Graphics
					// Reset selections
					gameView.resetDestination();
				} else if (sideView.getCurrentColor() == Constants.BLUE
						&& gameView.getDestination() == Constants.EMPTY) {
					// If the user only selected a blue piece
					infoLabel.setText("<html><b><font size=3>PLACE Blue Piece Down</font></b><br></html>");
				} else if (sideView.getCurrentColor() == Constants.RED
						&& gameView.getDestination() == Constants.EMPTY) {
					// If the user only selected a red piece
					infoLabel.setText("<html><b><font size=3>PLACE Red Piece Down</font></b><br></html>");
				}
			} else if (this.gameModel.getCurrPhase() == Constants.MOVE) {
				// Movement phase
				if (once) {
					if (gameModel.getCurrPlayer() == Constants.BLUE) {
						infoLabel.setText(
								"<html><b><font size=3>Please select BLUE piece to MOVE.</font></b><br></html>");
					} else {
						infoLabel.setText(
								"<html><b><font size=3>Please select RED piece to MOVE.</font></b><br></html>");
					}
					once = false;
				}
				if (aiPlaying && gameModel.getCurrPlayer() == (ai.getPlayer())) {
					gameModel.applyMove(ai.nextBestMove(gameModel)); // Apply
																		// move
					refresh(); // Refresh Graphics
					if (gameModel.getCurrPlayer() == Constants.BLUE) {
						infoLabel.setText(
								"<html><b><font size=3>Please select BLUE piece to MOVE.</font></b><br></html>");
					} else {
						infoLabel.setText(
								"<html><b><font size=3>Please select RED piece to MOVE.</font></b><br></html>");
					}
				}
				if (gameView.getDestination() != Constants.EMPTY) {
					if (currDestination != Constants.EMPTY) {
						gameModel.applyMove(
								new Move(gameModel.getCurrPlayer(), currDestination, gameView.getDestination()));
						refresh();
						if (gameModel.getCurrPlayer() == Constants.BLUE) {
							infoLabel.setText(
									"<html><b><font size=3>Please select BLUE piece to MOVE.</font></b><br></html>");
						} else {
							infoLabel.setText(
									"<html><b><font size=3>Please select RED piece to MOVE.</font></b><br></html>");
						}

						currDestination = Constants.EMPTY;
					} else {
						if (gameModel.getCurrPlayer() == gameModel.getGamestateAtIndex(gameView.getDestination())) {
							if (gameModel.getCurrPlayer() == Constants.BLUE) {
								infoLabel.setText("<html><b><font size=3>Blue piece selected</font></b><br></html>");
							} else {
								infoLabel.setText("<html><b><font size=3>Red piece selected</font></b><br></html>");
							}
							currDestination = gameView.getDestination();
						} else {
							JOptionPane.showMessageDialog(null, "Please choose a the correct colour!",
									"Invalid Selection", JOptionPane.ERROR_MESSAGE);
							currDestination = Constants.EMPTY;
						}
					}
					gameView.resetDestination();
				}
			} else if (this.gameModel.getCurrPhase() == Constants.MILL) {
				// Milling phase
				infoLabel.setText(
						"<html><b><font size=3>MILLING PHASE. Select Opponent's Colour!</font></b><br></html>");
				if (gameView.getDestination() != Constants.EMPTY) {
					gameModel.applyMove(new Move(gameModel.getCurrPlayer(), gameView.getDestination(), true));
					refresh(); // Refresh Graphics
					currDestination = Constants.EMPTY;
					gameView.resetDestination();
					once = true;
				} else if (aiPlaying && gameModel.getCurrPlayer() == (1 - ai.getPlayer())) {
					gameModel.applyMove(ai.nextBestMillMove(gameModel)); // Apply
					// move
					refresh(); // Refresh Graphics
				}
			}
		}
	}

	/**
	 * This method grabs an action performed if the user clicks on the menu. 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		JMenuItem source = (JMenuItem) (e.getSource());
		Random rand = new Random();
		String text = source.getText();
		if (text.equals("New game")) {
			// Create a new game
			gameModel = new Board(rand.nextInt(2));
			gameModel.setCurrPhase(Constants.PLACE);
			// Refresh everything
			refresh();
		} else if (text.equals("Load game")) {
			String filename = JOptionPane.showInputDialog("Enter the name of the game file you wish to load.");
			try {
				if (filename.equals("")) {
					loadGame();
				} else {
					loadGame("data/" + filename);
				}
			} catch (FileNotFoundException e1) {
				JOptionPane.showMessageDialog(null, "Unable to locate saved game file!", "File not Found",
						JOptionPane.ERROR_MESSAGE);
			}
		} else if (text.equals("Save game")) {
			try {
				String filename = JOptionPane.showInputDialog("Enter the name file name you wish to save the data to");
				if (filename.equals("")) {
					saveGame();
				} else {
					saveGame("data/" + filename);
				}

			} catch (FileNotFoundException e1) {
				JOptionPane.showMessageDialog(null, "Six Men's Morris ran into an error while trying to save the game",
						"Unable to save game", JOptionPane.ERROR_MESSAGE);
			}
		} else if (text.equals("Exit")){
			this.mainView.dispose();
        	System.exit(0);
		} else if (text.equals("Play with computer")) {
			aiPlaying = true;
			// Create a new game
			gameModel = new Board(rand.nextInt(2));
			gameModel.setCurrPhase(Constants.PLACE);
			// Refresh everything
			refresh();
		} else if (text.equals("2 Player")) {
			aiPlaying = false;
			// Create a new game
			gameModel = new Board(rand.nextInt(2));
			gameModel.setCurrPhase(Constants.PLACE);
			// Refresh everything
			refresh();
		}
	}
}
