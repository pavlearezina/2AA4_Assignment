package View;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JComponent;

import Model.Board;
import Resources.Constants;

public class SideBoardView extends JComponent{
	private final int HEIGHT = 200;
	private final int WIDTH = 200;
	private int[][] circlePositions;
	private Board gameData;
	private int curColor;
	
	/**
	 * Connects the View to the Controller, tells controller what colour on the side panel was clicked.
	 * @return curColor - The current colour
	 */
	public synchronized int getCurrentColor(){
		return gameData.getCurrPlayer();
	}
	/**
	 * Constructor - Connects the Model and the View, initialize the first colour, populate the circle positions, add mouse listener, and make visible. 
	 * @param gameData - Obtains the gameboard data
	 * @param start - Obtains randomly generated start number (0 or 1);
	 */
	public SideBoardView(Board gameData){
		this.gameData = gameData; //Set the game data
		this.curColor = gameData.getCurrPlayer(); //First colour is selected at random (in the view controller)
		fillCirclePositions(); //Generate all the positions for the cirlce
		this.setOpaque(true); //Set visible
	}
	/**
	 * This method allows outside function to set the board model. 
	 * @param gameData
	 */
	public void setBoard(Board gameData){
		//System.out.println("Player 1: " + gameData.getPlayer1().getNumPieceHolding());
		this.gameData = gameData; //Set the game data
	}
	/**
	 * Create the side board with blue and red circles.
	 */
	@Override
	public void paintComponent(Graphics g){
		//Draw the background
		g.setColor(new Color(243, 243, 243));
		g.fillRect(0, 0, this.WIDTH + 200, this.HEIGHT);
		for (int i = 0; i < 6; i++) {
			//For blue
			g.setColor(new Color(0, 0, 0));
			g.fillOval(circlePositions[i][0], 50, 20, 20);
		}
		for (int i = 6; i < 12; i++) {
			//For red
			g.setColor(new Color(0, 0, 0));
			g.fillOval(circlePositions[i][0], 100, 20, 20);
		}
		
		for (int i = 0; i < gameData.getPlayer1().getNumPieceHolding(); i++) {
			//For blue
			g.setColor(new Color(0, 0, 255));
			g.fillOval(circlePositions[i][0], 50, 20, 20);
		}
		for (int i = 6; i < gameData.getPlayer2().getNumPieceHolding()+6; i++) {
			//For red
			g.setColor(new Color(255, 0, 0));
			g.fillOval(circlePositions[i][0], 100, 20, 20);
		}
	}
	public Dimension getPreferredSize(){
		return new Dimension(this.WIDTH, this.HEIGHT);
	}

	/**
	 * Give each circle position an x and y coordinate on the view.
	 */
	private void fillCirclePositions(){
		circlePositions = new int[12][2];
		//Determines the positions of each circle on the view
		int x = 0;
		int y = 1;
		for (int i = 0; i < 6; i++) {
			circlePositions[i][x] = this.WIDTH/7*(i+1);
			circlePositions[i][y] = 50;
			circlePositions[i+6][x] = this.WIDTH/7*(i+1);
			circlePositions[i+6][y] = 100;
		}
	}
}
