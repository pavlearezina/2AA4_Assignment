package View;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JComponent;

import Model.Board;
import Model.Move;
import Resources.Constants;

public class GameBoardView extends JComponent implements MouseListener {

	private final int HEIGHT = 400; //Height of the view
	private final int WIDTH = 400; //Width of the view
	private int outerSideLength = 300; //Dimensions of the outside square
	private int innerSideLength = outerSideLength / 2; //Dimensions of the inner square
	private Board gameboard; //The game board data
	private int curDestination;
	
	private int[][] pieceLocation; //Location of each piece

	public int getWidth() {
		return this.WIDTH;
	}

	public int getHeight() {
		return this.HEIGHT;
	}
	/**
	 * Each position has an x-coordinate, this returns the x value
	 * @param i	Requires the index
	 * @return	returns the x coordinate
	 */
	public int getPieceX(int i) {
		return pieceLocation[i][0];
	}

	/**
	 * Each position has an y-coordinate, this returns the y value
	 * @param i Requires the index
	 * @return returns the y coordinate
	 */
	public int getPieceY(int i) {
		return pieceLocation[i][1];
	}
	/**
	 * Constructor for the GameBoardView. 
	 * - Sets the current destination to EMPTY 
	 * - Creates connection between Model and View
	 * - Creates all the positions locations
	 * - Adds a mouselistener
	 * - Make the view visible. 
	 * @param gameData
	 */
	public GameBoardView(Board gameData) {
		curDestination = Constants.EMPTY; //Initially no destination is selected
		this.gameboard = gameData; //Set the game data for the view
		this.fillPieceLocation(); //Determine all the locations of each piece 
		this.addMouseListener(this); //Add the mouselistener for user input
		this.setOpaque(true); //Make the view visisble. 
	}

	/**
	 * The view can take in a new gameboard data, this will set the gameboard data to the new one.
	 * @param newBoard Requires the new game board data
	 */
	public void setBoard(Board newBoard) {
		this.gameboard = newBoard;
	}

	/**
	 * Draws the Six-Men's morris gameboard. 
	 */
	@Override
	public void paintComponent(Graphics g) {
		int pieceOffset = 10;

		// Draw the background
		g.setColor(new Color(243, 243, 243));
		g.fillRect(0, 0, this.WIDTH + 200, this.HEIGHT);

		// Draw the outer square
		g.setColor(new Color(255, 240, 192));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 2, this.HEIGHT / 2 - outerSideLength / 2, outerSideLength,
				outerSideLength);

		// Draw outer-top line
		g.setColor(new Color(0, 0, 0));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 2, this.HEIGHT / 2 - outerSideLength / 2, outerSideLength, 2);

		// Draw outer-left line
		g.setColor(new Color(0, 0, 0));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 2, this.HEIGHT / 2 - outerSideLength / 2, 2, outerSideLength);

		// Draw bottom line
		g.setColor(new Color(0, 0, 0));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 2, this.HEIGHT / 2 - outerSideLength / 2 + outerSideLength,
				outerSideLength, 2);

		// Draw bottom line
		g.setColor(new Color(0, 0, 0));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 2 + outerSideLength, this.HEIGHT / 2 - outerSideLength / 2, 2,
				outerSideLength);

		// Draw vertical-middle line
		g.setColor(new Color(0, 0, 0));
		g.fillRect(this.WIDTH / 2 - 1, this.HEIGHT / 2 - outerSideLength / 2, 2, outerSideLength);

		// Draw horizontal-middle line
		g.setColor(new Color(0, 0, 0));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 2, this.HEIGHT / 2 - 1, outerSideLength, 2);

		// Inner box
		g.setColor(new Color(0, 0, 0));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 4 - 2, this.HEIGHT / 2 - outerSideLength / 4 - 2,
				innerSideLength + 4, innerSideLength + 4);

		// Draw the inner square
		g.setColor(new Color(255, 240, 192));
		g.fillRect(this.WIDTH / 2 - outerSideLength / 4, this.HEIGHT / 2 - outerSideLength / 4, outerSideLength / 2,
				outerSideLength / 2);

		// Piece Location
		for (int i = 0; i < pieceLocation.length; i++) {
			if (gameboard.getGamestateAtIndex(i) == Constants.EMPTY) {
				//If game state is empty...
				g.setColor(new Color(0, 0, 0));
				g.fillOval(pieceLocation[i][0] - pieceOffset, pieceLocation[i][1] - pieceOffset, 20, 20);
			} else if (gameboard.getGamestateAtIndex(i) == Constants.BLUE) {
				//If the game state is blue...
				g.setColor(new Color(0, 0, 255));
				g.fillOval(pieceLocation[i][0] - pieceOffset, pieceLocation[i][1] - pieceOffset, 20, 20);
			} else {
				//if the game state is red...
				g.setColor(new Color(255, 0, 0));
				g.fillOval(pieceLocation[i][0] - pieceOffset, pieceLocation[i][1] - pieceOffset, 20, 20);
			}
		}
	}

	public Dimension getPreferredSize() {
		return new Dimension(this.WIDTH, this.HEIGHT);
	}
	/**
	 * Allows outside objects/classes to reset the current destination of this class.
	 */
	public void resetDestination(){
		curDestination = Constants.EMPTY;
	}
	/**
	 * Creates a connection from the view to the controller
	 * @return curDesintation the current destination that the user wants to go to.
	 */
	public synchronized int getDestination() {
		return this.curDestination;
	}
	/**
	 * Determines the closest position that the user clicked on and sets the current desintation to that position. 
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		int best = 0, bestDist = Integer.MAX_VALUE;

		//Go through each piece location x and y coordinate
		for (int i = 0; i < pieceLocation.length; i++) {
			int x = this.getPieceX(i);
			int y = this.getPieceY(i);
			int x2 = e.getX();
			int y2 = e.getY();
			int dist = ((x - x2) * (x - x2) + (y - y2) * (y - y2)); //how far away it is form the point
			if (dist < bestDist) {
				bestDist = dist;
				best = i; //remeber the closest position
			}
		}
		curDestination = best;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
	/**
	 * Generates the X and Y coordinates for each piece location.
	 */
	private void fillPieceLocation() {
		// Create a temporary
		int[][] pieceLocation = new int[gameboard.getNumSpots()][2];
		// for convenience and understanding, say x = 0, y = 1
		int x = 0; // x coordinate
		int y = 1;// y coordinate

		// For each location, we calculated that these should be the position
		pieceLocation[0][x] = this.WIDTH / 2 - outerSideLength / 2;
		pieceLocation[0][y] = this.HEIGHT / 2 - outerSideLength / 2;
		pieceLocation[1][x] = this.WIDTH / 2;
		pieceLocation[1][y] = this.HEIGHT / 2 - outerSideLength / 2;
		pieceLocation[2][x] = this.WIDTH / 2 + outerSideLength / 2;
		pieceLocation[2][y] = this.HEIGHT / 2 - outerSideLength / 2;
		pieceLocation[3][x] = this.WIDTH / 2 - outerSideLength / 4;
		pieceLocation[3][y] = this.HEIGHT / 2 - outerSideLength / 4;
		pieceLocation[4][x] = this.WIDTH / 2 - 1;
		pieceLocation[4][y] = this.HEIGHT / 2 - outerSideLength / 4 - 2;
		pieceLocation[5][x] = this.WIDTH / 2 + outerSideLength / 4;
		pieceLocation[5][y] = this.HEIGHT / 2 - outerSideLength / 4 - 2;
		pieceLocation[6][x] = this.WIDTH / 2 - outerSideLength / 2;
		pieceLocation[6][y] = this.HEIGHT / 2;
		pieceLocation[7][x] = this.WIDTH / 2 - outerSideLength / 4 - 2;
		pieceLocation[7][y] = this.HEIGHT / 2;
		pieceLocation[8][x] = this.WIDTH / 2 + outerSideLength / 4;
		pieceLocation[8][y] = this.HEIGHT / 2;
		pieceLocation[9][x] = this.WIDTH / 2 + outerSideLength / 2;
		pieceLocation[9][y] = this.HEIGHT / 2;
		pieceLocation[10][x] = this.WIDTH / 2 - outerSideLength / 4;
		pieceLocation[10][y] = this.HEIGHT / 2 + outerSideLength / 4;
		pieceLocation[11][x] = this.WIDTH / 2 - 1;
		pieceLocation[11][y] = this.HEIGHT / 2 + outerSideLength / 4;
		pieceLocation[12][x] = this.WIDTH / 2 + outerSideLength / 4;
		pieceLocation[12][y] = this.HEIGHT / 2 + outerSideLength / 4;
		pieceLocation[13][x] = this.WIDTH / 2 - outerSideLength / 2;
		pieceLocation[13][y] = this.HEIGHT / 2 + outerSideLength / 2;
		pieceLocation[14][x] = this.WIDTH / 2;
		pieceLocation[14][y] = this.HEIGHT / 2 + outerSideLength / 2;
		pieceLocation[15][x] = this.WIDTH / 2 + outerSideLength / 2;
		pieceLocation[15][y] = this.HEIGHT / 2 + outerSideLength / 2;

		// Set the global variable
		this.pieceLocation = pieceLocation;
	}

}
