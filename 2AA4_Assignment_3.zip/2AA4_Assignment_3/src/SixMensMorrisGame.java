import Controller.MainStoryBoard;

/**
 * This class is the starting point of the game. This class contains the main function where the view controller is created and the game begins. 
 * @author alexnguyen
 *
 */
public class SixMensMorrisGame {

	/**
	 * Main function where the game starts. This method is the game server where the view controller MainStoryBoard is created. 
	 * @param args
	 */
	public static void main(String[] args) {
		//Start the game 
		MainStoryBoard mainStoryboard = new MainStoryBoard();
		mainStoryboard.playGame();
	}
}
