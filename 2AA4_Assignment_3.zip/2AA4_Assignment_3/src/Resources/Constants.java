package Resources; //

/**
 * Stores all the constants that are universally used throughoutt the
 * application.
 * 
 * @author alexnguyen
 *
 */
public class Constants {
	public static final int BLUE = 0;
	public static final int RED = 1;
	public static final int EMPTY = -1;
	public static final int numPiecesPerPlayer = 6;
	public static final int PLACE = 0;
	public static final int MOVE = 1;
	public static final int MILL = 2;
	public static final int MAX_DEPTH = 25; //new 
}
