package Model; //

import Resources.Constants;

public class Player {
	//Private variable declaration
	private int color;
	private int numMills;
	private int numPiecesHolding;
	private int numPiecesOnTable;
	
	/**
	 * Each player has a color (RED OR BLUE), this method will return the color.
	 * @return
	 */
	public int getColor(){
		return this.color;
	}
	/**
	 * Gets number of mills
	 * @return
	 */
	public int getNumMills(){
		return this.numMills;
	}
	/**
	 * Increment the number of mills by 1
	 */
	public void incNumMills(){
		this.numMills++;
	}
	/**
	 * Decrement the number of mills by 1
	 */
	public void decNumMills(){
		this.numMills--;
	}
	/**
	 * Decrease piece holding. If the number of pieces is greater than 0 then it is decremented by 1
	 */
	public void decreasePieceholding(){
		if (this.numPiecesHolding > 0){
			this.numPiecesHolding--;
		}
	}
	/**
	 * Gets the number of pieces currently holding
	 * @return
	 */
	public int getNumPieceHolding(){
		return this.numPiecesHolding;
	}
	/**
	 * Gets number of pieces on table
	 * @return
	 */
	public int getNumPiecesOnTable(){
		return this.numPiecesOnTable;
	}
	/**
	 * Constructor for player, sets the color according to parameter received
	 * Initiates number of pieces on table and number of mills to 0.
	 */
	public Player(int color){
		this.color = color;
		this.numPiecesOnTable = 0;
		this.numMills = 0;
		this.numPiecesHolding = Constants.numPiecesPerPlayer;
	}
	/**
	 * Constructor for a player with more information.
	 * @param color
	 * @param numMills
	 * @param numPiecesHolding
	 * @param numPiecesOnTable
	 */
	public Player(String color, String numMills, String numPiecesHolding, String numPiecesOnTable){
		this.color = Integer.parseInt(color);
		this.numMills = Integer.parseInt(numMills);
		this.numPiecesHolding = Integer.parseInt(numPiecesHolding);
		this.numPiecesOnTable = Integer.parseInt(numPiecesOnTable);
	}
	/**
	 * Converts the data of the Player into a string. 
	 */
	public String toString(){
		return color + "," + numMills + "," + numPiecesHolding + "," + numPiecesOnTable;
	}
}
