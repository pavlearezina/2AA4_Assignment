package Model; //

import javax.swing.JOptionPane;

import Resources.Constants;

public class Board {
	// Properties of the board
	private Player currPlayer; // NEW
	private Player winner;
	public boolean GAMEOVER = false;
	private int currPhase;
	private Player player1;
	private Player player2;
	private final int NUM_SPOTS = 16; // Set number of spots here
	private int[] gameState; // The represents the game map
	private final int[][] adjacent = { { 1, 6 }, { 0, 2, 4 }, { 1, 9 }, { 4, 7 }, { 1, 3, 5 }, { 4, 8 }, { 0, 13, 7 },
			{ 3, 6, 10 }, { 5, 9, 12 }, { 2, 8, 15 }, { 7, 11 }, { 10, 12, 14 }, { 11, 8 }, { 6, 14 }, { 11, 13, 15 },
			{ 9, 14 } }; // All position adjacentcies

	// All the possible milling positions.
	private final int[][] mills = { { 0, 1, 2 }, { 3, 4, 5 }, { 10, 11, 12 }, { 13, 14, 15 }, { 0, 6, 13 },
			{ 3, 7, 10 }, { 5, 8, 12 }, { 2, 9, 15 } };

	/**
	 * If there is a winner, this method returns the winning player
	 * @return
	 */
	public Player getWinner() {
		if (winner != null) {
			return this.winner;
		} else {
			return null;
		}
	}
	
	/**
	 * This method obtains what is at position i
	 * 
	 * @param i
	 *            Requires the index at which position is in question
	 * @return Return what is in the position (Empty, Blue or Red)
	 */
	public int getGamestateAtIndex(int i) {
		return gameState[i];
	}
	
	/**
	 * The method returns the current phase (either Move, Mill or Placement)
	 * @return
	 */
	public int getCurrPhase() {
		return currPhase;
	}

	/**
	 * This method returns all of the data of player 1
	 * @return
	 */
	public Player getPlayer1() {
		return player1;
	}

	/**
	 * This method returns all the data of player 2
	 * @return
	 */
	public Player getPlayer2() {
		return player2;
	}

	/**
	 * This method returns the current player 
	 * @return
	 */
	public int getCurrPlayer() {
		return currPlayer.getColor();
	}
	
	/**
	 * The board contains the max number of spots, this can be changed in the
	 * future
	 * 
	 * @return number of spots
	 */
	public int getNumSpots() {
		return this.NUM_SPOTS;
	}
	/**
	 * Returns the number of mills for player 1
	 * 
	 * @return player 1 number mills
	 */
	public int getPlayer1NumMills() {
		return player1.getNumMills();
	}
	/**
	 * Returns the number of mills for player 2
	 * 
	 * @return player 2 number of mills
	 */
	public int getPlayer2NumMills() {
		return player2.getNumMills();
	}

	/**
	 * Returns the positions that are adjacent to a desired position
	 * 
	 * @param piece
	 * @return
	 */
	public int[] getAdjacent(int piece) {
		return this.adjacent[piece];
	}
	/**
	 * This method sets the current phase of the game. 
	 * @param newPhase
	 */
	public void setCurrPhase(int newPhase) {
		this.currPhase = newPhase;
	}

	
	/**
	 * (Setter Method) The method allows other classes to change player 1
	 * @param player
	 */
	public void setPlayer1(Player player) {
		this.player1 = player;
	}
	/**
	 * (Setter Method) This method allows other classes to change player 2
	 * @param player
	 */
	public void setPlayer2(Player player) {
		this.player2 = player;
	}
	/**
	 * (Setter Method) This method allows other classes to change the current player
	 * @param startPlayer
	 */
	public void setCurrPlayer(int startPlayer) {
		if (startPlayer == Constants.BLUE) {
			currPlayer = player1;
		} else {
			currPlayer = player2;
		}
	}
	/**
	 * (Setter Method) This method allows other classes to load new game data
	 * @param gameState
	 */
	public void loadGameData(String[] gameState) {
		for (int i = 0; i < gameState.length; i++) {
			this.gameState[i] = Integer.parseInt(gameState[i]);
		}
	}
	/**
	 * Board constructor: create a new gamestate the size of the number of spots
	 * and creates a new gamestate
	 */
	public Board() {
		// Initialize a new game state
		gameState = new int[NUM_SPOTS];
		// Create player 1 and player 2
		player1 = new Player(Constants.BLUE);
		player2 = new Player(Constants.RED);
		// Create new Game State
		currPlayer = player1;
		this.newGameState();
	}
	/**
	 * This constructor creates a new game state and is able to take in the starting player parameter. 
	 * @param startingPlayer
	 */
	public Board(int startingPlayer) {
		// Initialize a new game state
		gameState = new int[NUM_SPOTS];
		// Create player 1 and player 2
		player1 = new Player(Constants.BLUE);
		player2 = new Player(Constants.RED);
		if (startingPlayer == 0) {
			currPlayer = this.player1;
		} else {
			currPlayer = this.player2;
		}
		// Create new Game State
		this.newGameState();
	}

	/**
	 * This method creates a new game state setting each spot all to EMPTY
	 */
	public void newGameState() {
		//Set all the positions to empty
		for (int i = 0; i < NUM_SPOTS; i++) {
			gameState[i] = Constants.EMPTY;
		}
	}

	/**
	 * This method applies a move to the board and will modify the board
	 * accordingly
	 * 
	 * @param move
	 *            Requires a move, either PLACE, MOVE or MILL (for future uses)
	 */
	public void applyMove(Move move) {
		if (move.getType() == Constants.PLACE) {
			if (gameState[move.getDestination()] == Constants.EMPTY) {
				this.currPlayer.decreasePieceholding();
				// If the destination is empty...
				gameState[move.getDestination()] = move.getPlayer().getColor();
				if (isInMill(move.getPlayer(), move.getDestination())) {
					// If a new mill is created...
					if (player1.getColor() == move.getPlayer().getColor()) {
						player1.incNumMills(); // Increase mill
					} else if (player2.getColor() == move.getPlayer().getColor()) {
						player2.incNumMills();// Increase mill
					}
				}
			}
			this.alternateCurrPlayer();
			if (isInMill(move.getPlayer(), move.getDestination())) {
				this.setCurrPhase(Constants.MILL);
			} else if (this.player1.getNumPieceHolding() == 0 && this.player2.getNumPieceHolding() == 0) {
				this.setCurrPhase(Constants.MOVE);
				canMove();
			}
		} else if (move.getType() == Constants.MOVE) {
			//if movement phase, move piece and check if game is over
			movePieces(move);
			canMove();
		} else if (move.getType() == Constants.MILL) {
			//If the piece is not in a mill, and there are pieces that you can delete, delete the pieces
			if (!isInMill(move.getPlayer(), move.getDestination()) || !canDelete()) {
				deletePieces(move.getPlayer(), move.getDestination());
			} else {
				JOptionPane.showMessageDialog(null, "The piece is currently in a mill, try another piece",
						"Invalid Selected", JOptionPane.ERROR_MESSAGE);
			}
		}

		//When each player has less than 2 pieces, end the game
		if (currPhase == Constants.MOVE && (this.countBlue() <= 2 || this.countRed() <= 2)) {
			GAMEOVER = true;
			alternateCurrPlayer();
			winner = this.currPlayer;
		}
	}
	/**
	 * This method is helper method for this class to determine if there are pieces to remove that are not in mills. 
	 * @return
	 */
	public boolean canDelete() {
		//Check if a piece (not in a mill) is deletable
		for (int i = 0; i < gameState.length; i++) {
			if (gameState[i] == this.getCurrPlayer()) {
				if (!this.isInMill(currPlayer, i)) {
					return true;
				}
			}
		}
		GAMEOVER = true;
		return false;
	}
	/**
	 * This method is a helper function that counts the number of blue pieces on the board. The method searches through the game state array for all blue pieces.
	 * @return
	 */
	private int countBlue() {
		//Keep track of how many blue pieces there are 
		int returnVal = 0;
		for (int i = 0; i < gameState.length; i++) {
			if (gameState[i] == Constants.BLUE) {
				returnVal++;
			}
		}
		return returnVal;
	}

	/**
	 * This method is a helper function that counts the number of red pieces on the board. The method searches through the game state array for all red pieces.
	 * @return
	 */
	private int countRed() {
		//Keep track of how many red pieces there are
		int returnVal = 0;
		for (int i = 0; i < gameState.length; i++) {
			if (gameState[i] == Constants.RED) {
				returnVal++;
			}
		}
		return returnVal;
	}

	/**
	 * This helper method performs a deletion by changing the gamestate destination to empty and changes the current game phase if needed. 
	 * @param player
	 * @param destination
	 */
	private void deletePieces(Player player, int destination) {
		//Check colour and change position to empty
		if (gameState[destination] == (player.getColor())) {
			gameState[destination] = Constants.EMPTY;
			if (this.player1.getNumPieceHolding() == 0 && this.player2.getNumPieceHolding() == 0) {
				this.setCurrPhase(Constants.MOVE);
			} else {
				this.setCurrPhase(Constants.PLACE);
			}
		}
	}

	/**
	 * This helper function determines if the opposing player. If the player is unable to move, this function ends the game. 
	 * @return
	 */
	private boolean canMove() {
		//Search through adjacentcy lists and check that all adjacent spots are filled
		for (int i = 0; i < gameState.length; i++) {
			if (gameState[i] == this.currPlayer.getColor()) {
				for (int j = 0; j < adjacent[i].length; j++) {
					if (gameState[adjacent[i][j]] == Constants.EMPTY) {
						return true;
					}
				}
			}
		}
		GAMEOVER = true;
		alternateCurrPlayer();
		winner = this.currPlayer;
		return false;
	}

	/**
	 * This helper method determines if a position x is adjacent to a position y. 
	 * @param x
	 * @param y
	 * @return
	 */
	private boolean isAnAdjacent(int x, int y) {
		//Search through the adjacentcy list for a particular position and check if y is in there. 
		for (int i = 0; i < getAdjacent(x).length; i++) {
			if (y == getAdjacent(x)[i]) {
				return true;
			}
		}
		return false;
	}

	/**
	 * This helper function performs the function of moving a piece. If it is able to move a piece, it changes the current player and/or the current phase. 
	 * @param move
	 */
	private void movePieces(Move move) {
		//If the destination is empty, move the piece there. 
		if (gameState[move.getDestination()] == Constants.EMPTY
				&& isAnAdjacent(move.getFrom(), move.getDestination())) {
			gameState[move.getDestination()] = gameState[move.getFrom()];
			gameState[move.getFrom()] = Constants.EMPTY;
			this.alternateCurrPlayer();
			if (isInMill(move.getPlayer(), move.getDestination())) {
				this.setCurrPhase(Constants.MILL);
			}
		}
	}

	/**
	 * This method checks if a player has formed a mill, returns a boolean
	 * 
	 * @param player
	 *            is passed on to function to check if they have formed a mill
	 * @param position
	 *            an integer in range 1-16 of the current position of piece
	 */
	public boolean isInMill(Player player, int position) {
		boolean oneColor = true;
		// Go through all milling combinations and search for the position. Once
		// position is found look through that array and make sure the other two
		// positions are the same colour.
		for (int i = 0; i < mills.length; i++) {
			for (int j = 0; j < mills[i].length; j++) {
				if (position == mills[i][j]) {
					for (int j2 = 0; j2 < mills[i].length; j2++) {
						if (gameState[mills[i][j2]] != gameState[position]) {
							oneColor = false;
						}
					}
					if (oneColor) {
						return true;
					}
					oneColor = true;
				}
			}
		}
		return false;
	}

	/**
	 * This method alternates the current player. 
	 */
	private void alternateCurrPlayer() {
		if (currPlayer == player1) {
			currPlayer = player2;
		} else {
			currPlayer = player1;
		}
	}
	/**
	 * This method converts the Board ADT into a string. This method will save
	 * the gameState array, current player, current phase and the toString() for
	 * each player.
	 */
	public String toString() {
		// Initialize the return string
		String out = "";
		// Go through the game state and add it into the return string,
		// separating each entry with a comma.
		for (int i = 0; i < gameState.length; i++) {
			out += gameState[i] + ",";
		}

		// Include player 1
		out += "\n" + this.getPlayer1().toString();
		// Include Player 2
		out += "\n" + this.getPlayer2().toString();
		// Include the current player
		out += "\n" + this.getCurrPlayer();
		// Include the current phase;
		out += "\n" + this.getCurrPhase();
		// Return the string
		return out;
	}
	public void setGameStateAt(int i, int color){
			gameState[i] = color;
	}
}
