package Model;

import java.util.Random;

import Resources.Constants;

public class AI {
	private Player player;
	/**
	 * The constructor creates an AI from a player. Each AI has a player attribute, mainly the number of pieces holding and the colour for the AI.
	 * @param player
	 */
	public AI(Player player){
		//Set the player property
		this.player = player;
	}
	/**
	 * Returns the colour of the AI
	 * @return
	 */
	public int getPlayer(){
		return player.getColor();
	}
	/**
	 * Reads in the board and determines the next best Move during a milling situation. The method chooses a random destination that make sures the position has the opposing player's piece. 
	 * This method makes sure that the selected position is not in a mill. 
	 * @param board Requires some voard data.
	 * @return the next best Milling move. 
	 */
	public Move nextBestMillMove(Board board){
		int removeDestination = -1;
		Random rn = new Random();
		
		//Keep generating positions until the selected position is allowed. 
		while (true){
			removeDestination = rn.nextInt(board.getNumSpots()); //Generate random position. 
			if (board.getGamestateAtIndex(removeDestination) == (1-player.getColor()) && !board.isInMill(player, removeDestination)){
				//Check if opposite player and not in a mill.
				break;
			} else if (board.getGamestateAtIndex(removeDestination) == (1-player.getColor()) && !board.canDelete()){
				//If all pieces are in a mill, then allow for deletion of a piece in a mill. 
				break;
			}
		}
		return new Move(board.getCurrPlayer(), removeDestination, true); //Return a new move. 
	}

	/**
	 * This method returns the next best move during the Movement phase. 
	 * @param board
	 * @return
	 */
	public Move nextBestMove(Board board){
		//Create arbitrary best move. 
		int[] bestMove = new int[3];
		bestMove[0] = -1;
		bestMove[1] = -1;
		bestMove[2] = -1;
		int[] temp;
		//For all positions on the positions on the board, if the position is the player's piece, determine the movement value based on greedy algorithm. 
		for (int i = 0; i < board.getNumSpots(); i++) {
			if (board.getGamestateAtIndex(i) == player.getColor()){
				temp = calcMoveValue(board, i);
				if (temp[1] > bestMove[1]){
					//If a better move is found, set the best move. 
					bestMove = temp;
				}
			}
		}
		//In the case all moves are equal, generate a random move. 
		if (bestMove[1] == -1){
			int[] randomMove = generateRandomMoveMove(board);
			return new Move(board.getCurrPlayer(), randomMove[0], randomMove[1]);
		}
		//Return move. 
		return new Move(board.getCurrPlayer(), bestMove[0], bestMove[2]);
	}
	/**
	 * This method generates a value based on a greedy algorithm. 
	 * This method returns an array that is the from position, the to position and the value of the move. 
	 * @param board
	 * @param from
	 * @return
	 */
	public int[] calcMoveValue(Board board, int from){
		int[] returnArray = new int[3];
		returnArray[0]=from;
		returnArray[1] = -1;
		returnArray[2] = -1;
		for (int i = 0; i < board.getAdjacent(from).length; i++) {
			int destination = board.getAdjacent(from)[i];
			if (board.getGamestateAtIndex(destination) == Constants.EMPTY){
				board.setGameStateAt(from, Constants.EMPTY);
				if (getPlaceValue(destination, board) > returnArray[1]){
					returnArray[1] = getPlaceValue(destination, board);
					returnArray[2] = destination;
				}
				board.setGameStateAt(from, player.getColor());
			}
		}
		return returnArray;
	}
	/**
	 * In the case that all moves are deemed equal, this method generates a random valid move. 
	 * @param board
	 * @return
	 */
	private int[] generateRandomMoveMove(Board board){
		int[] returnArray = new int[2];
		Random rn = new Random();
		while (true){
			int from = rn.nextInt(board.getNumSpots());
			if (board.getGamestateAtIndex(from) == player.getColor()){
				for (int i = 0; i < board.getAdjacent(from).length; i++) {
					int destination = board.getAdjacent(from)[i];
					if (board.getGamestateAtIndex(destination) == Constants.EMPTY){
						returnArray[0] = from;
						returnArray[1] = destination;
						return returnArray;
					}
				}
			}
		}
	}
	/**
	 * This method determines the best move during the Placement stage. 
	 * @param board
	 * @return
	 */
	public Move nextBestPlaceMove(Board board) {
		//Initiate the next best move.
		int bestMove = -1;
		int bestScore = -1;
		//For all empty spaces on the board, determine its value. 
		for (int i = 0; i < board.getNumSpots(); i++) {
			if (board.getGamestateAtIndex(i) == Constants.EMPTY){
				if (getPlaceValue(i, board) > bestScore){
					bestScore = getPlaceValue(i, board);
					bestMove = i;
				}
			}
		}
		//if all positions are of equal value, generate a random placement move. 
		if (bestScore == -1){
			bestMove = generateRandomMove(board);
		}
		return new Move(player.getColor(), bestMove);
	}
	/**
	 * This method generates a valid random placement move. 
	 * @param board
	 * @return
	 */
	private int generateRandomMove(Board board){
		//Initiate the position for next best move. 
		int bestMove = -1;
		//Rnadom number generator
		Random rn = new Random();
		//Generate a random position and check that the space is empty. Return that position. 
		while (true){
			int answer = rn.nextInt(board.getNumSpots());
			if (board.getGamestateAtIndex(answer) == Constants.EMPTY){
				bestMove = answer;
				break;
			}
		}
		return bestMove;
	}

	/**
	 * This method uses a greedy algorithm to determine the value of a move:
	 * 4 pts : Can form a mill
	 * 3 pts : blocks opponent mill
	 * 1 pts: does not move beside an oppositement's piece. 
	 * @param destination
	 * @param board
	 * @return
	 */
	private int getPlaceValue(int destination, Board board){
		//Create a new board
		Board newBoard = newBoard(board);
		//Create a new temporary game state
		newBoard.setGameStateAt(destination, player.getColor());
		//If the destination creates a mill, return value of 4. 
		if (newBoard.isInMill(player, destination)){
			return 4;
		}
		//Create a new board
		newBoard = newBoard(board);
		//set the game state
		newBoard.setGameStateAt(destination, board.getPlayer2().getColor());
		//If the destination blocks a mill, return 3 pts. 
		if (newBoard.isInMill(board.getPlayer2(), destination)){
			return 3;
		}
		//If the position is not beside a another player's piece (don't want to get blocked), return 1 pt. 
		for (int i = 0;  i < board.getAdjacent(destination).length; i++){
			if (board.getGamestateAtIndex(i) != player.getColor() && board.getGamestateAtIndex(destination) == Constants.EMPTY){
				return 1;
			} 
		}
		//If no good moves, return -1 points. 
		return -1;
	}
	/**
	 * Creates a new board data from an existing board. Need to use this method so that we do not modify the real game data. 
	 * @param board
	 * @return
	 */
	private Board newBoard(Board board){
		//Create new board.
		Board newBoard = new Board();
		//Copy board data over. 
		for (int i = 0; i < board.getNumSpots(); i++){
			newBoard.setGameStateAt(i, board.getGamestateAtIndex(i));
		}
		return newBoard;
	}
}
