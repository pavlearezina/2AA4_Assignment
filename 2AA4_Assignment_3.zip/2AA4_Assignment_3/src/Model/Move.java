package Model;//

import Resources.Constants;

public class Move {
	private int type;
	private Player player;
	private int from;
	private int destination;
	
	/**
	 * Getter method that returns the starting destination of a move. 
	 * @return
	 */
	public int getFrom(){
		return this.from;
	}
	/**
	 * Getter method that returns the ending destination of a move
	 * @return
	 */
	public int getType(){
		return this.type;
	}
	/**
	 * Each move has a player associated with it (RED OR BLUE), this method will return the player of that move.
	 * @return
	 */
	public Player getPlayer(){
		return this.player;
	}
	/**
	 * Each move has a destination (index on the board), this method will return the destination the player wishes to move to
	 * @return
	 */
	public int getDestination(){
		return this.destination;
	}
	/**
	 * This constructor creates a move, currently only supports a 'PLACE' move. 
	 * @param player requires the piece that needs to be moved
	 * @param destination require the destination the piece must be moved to. 
	 */
	public Move(int player, int destination){
		this.type = Constants.PLACE;
		this.player = new Player(player);
		this.destination = destination;
	}
	/**
	 * Constructor to create a move that supports a MOVE phase. 
	 * @param player
	 * @param from
	 * @param to
	 */
	public Move(int player, int from, int to){
		this.type = Constants.MOVE;
		this.from = from;
		this.player = new Player(player);
		this.destination = to;
	}
	/**
	 * Constructor to create a move that supports a MILL pgase
	 * @param player
	 * @param delete
	 * @param random
	 */
	public Move(int player, int delete, boolean random){
		this.type = Constants.MILL;
		this.player = new Player(player);
		this.destination = delete;
	}
}
